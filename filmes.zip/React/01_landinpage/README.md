# 🎬 MovieCity — Landing Page

Landing page responsiva de um serviço de streaming fictício, construída com **React + Vite** e **CSS puro**. Projeto de prática de componentização, estilização e responsividade.

![Resultado esperado](./resultado-esperado.png)

## 🎯 O que o projeto faz

- **Header:** logo "MovieCity", menu de navegação (Filmes, Categoria, Sobre, Contato) e botão de Login.
- **Main:** texto de chamada ("Seus Filmes") com botão **Mais** e um grid com 6 cards de filmes (Afterlife, Transformers, Mowgli, Shift, Round 6 e Harry Potter).
- **Responsivo:** em telas pequenas as colunas se empilham, o grid passa a ter 2 colunas e o menu vira um hambúrguer.

## 🧰 Tecnologias

React 19 · Vite 7 · JavaScript (ESM) · CSS puro · ESLint

## ✅ Pré-requisitos

- Node.js 20.19+ ou 22.12+
- npm

## 🚀 Como executar

```bash
npm install
npm run dev
```

Acesse http://localhost:5173.

| Comando           | Descrição                                   |
| ----------------- | ------------------------------------------- |
| `npm run dev`     | Servidor de desenvolvimento (HMR)           |
| `npm run build`   | Build de produção em `dist/`                |
| `npm run preview` | Pré-visualização do build                   |
| `npm run lint`    | Análise estática com ESLint                 |

## 📁 Estrutura

```
01_landinpage/
├── public/vite.svg          # favicon
├── src/
│   ├── assets/              # pôsteres dos filmes
│   ├── components/
│   │   ├── Header.jsx       # cabeçalho + menu hambúrguer
│   │   ├── Main.jsx         # texto de chamada + grid de filmes
│   │   └── Home.jsx         # container da página
│   ├── App.jsx
│   ├── index.css            # estilos globais + responsividade
│   └── main.jsx
├── index.html
├── eslint.config.js
├── package.json
└── vite.config.js
```

## 📱 Responsividade

| Breakpoint        | O que muda                                           |
| ----------------- | ---------------------------------------------------- |
| `max-width: 1100px` | Espaçamentos e tipografia menores                  |
| `max-width: 900px`  | Colunas empilham, menu hambúrguer aparece          |
| `max-width: 600px`  | Grid de cards com 2 colunas, fontes menores        |
| `max-width: 380px`  | Ajustes finos de fonte e altura dos cards          |
